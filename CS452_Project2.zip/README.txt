Michael Farden and Matthew Strenk
Project 2
CS452

For our project we decided to make an office scene.  In this scene
there is a desk, chair, and a laptop for a total of 3 pieces.  The 
project has 13 polyhedra andhas 156 triangles.  The desk is made up of 
an prism for the top and 4 prisms for the legs of the desk.  The chair 
is made of a prism for the back seat and prisms for the legs of the chair.
The laptop is made of a prism for the screen and a prism for the
keyboard.  All of the objects have textures that have been given to them.
For example, the chair has a light wooden texture, the desk has a darker
wood texture, and the laptop has a metal texture.  The scene is viewed
from a perspective point of view.  The char has the ability to move 
along the postive and negative directions of the x-axis.  There are no
lighting aspects of the scene.  This is because we could not get them
to work.